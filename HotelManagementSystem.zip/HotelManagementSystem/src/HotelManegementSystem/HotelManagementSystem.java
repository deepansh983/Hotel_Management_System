package HotelManegementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HotelManagementSystem extends JFrame implements ActionListener {
    //make a constructor to open the frame after initiating the object
    HotelManagementSystem(){
        //make a frame
        setSize(1366,565);
        setLocation(100,100);
        setLayout(null);

        //to insert image use ImageIcon and create object for ImageIcon class
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/first.jpg"));

        //to place image on frame use JLabel class and create object for JLabel class
        JLabel image=new JLabel(i1);
        image.setBounds(0,0,1366,565); //location x,location y,length,breadth
        add(image);           //use add function to add component on frame

        //To insert text on frame use JLabel and create object
        JLabel text=new JLabel("HOTEL MANAGEMENT SYSTEM");
        text.setBounds(20,440,1000,90);
        text.setForeground(Color.WHITE); //setForeground use for font color
        text.setFont(new Font("serif",Font.PLAIN,50));
        image.add(text);   //to insert text on image

        //to create button use JButton
       JButton next=new JButton("NEXT");
       next.setBounds(1150,450,150,50);
       next.setForeground(Color.magenta);
       next.setBackground(Color.white);
       next.setFont(new Font("serif",Font.PLAIN,20));
       next.addActionListener(this);
       image.add(next);

        setVisible(true);

        //for creating dipper function for text
        while(true)
        {
            text.setVisible(false);
            try{
                Thread.sleep(500);
            }catch (Exception e)
            {
                e.printStackTrace();
            }
            text.setVisible(true);
            try{
                Thread.sleep(500);
            }catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    public void actionPerformed(ActionEvent ae){
        setVisible(false);    //it closes the current frame
        new Login();          //new frame open
    }

    public static void main(String [] args)
    {
        //create an object for a class
        new HotelManagementSystem();
    }
}
