package HotelManegementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame implements ActionListener {
    //create constructor
    Dashboard(){
        setBounds(0,0,1920,1080);
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
        Image i2=i1.getImage().getScaledInstance(1920,1080, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(0,0,1920,1080);
        add(image);

        //create text
        JLabel text=new JLabel("THE TAJ GROUP WELCOMES YOU");
        text.setBounds(400,80,1000,50);
        text.setFont(new Font("tahoma",Font.PLAIN,46));
        text.setForeground(Color.white);
        image.add(text);

        //create manu bar
        JMenuBar mb=new JMenuBar();
        mb.setBounds(0,0,1920,30);
        image.add(mb);

        //add hotel management menu to menu bar
        JMenu hotel=new JMenu("HOTEL MANAGEMENT");
        hotel.setForeground(Color.MAGENTA);
        mb.add(hotel);

        //add  admin menu to menu bar
        JMenu admin=new JMenu("ADMIN");
        admin.setForeground(Color.BLUE);
        mb.add(admin);

        //create drop down to hotel management menu using JMenuItem -reception
        JMenuItem reception=new JMenuItem("RECEPTION");
        reception.addActionListener(this);
        hotel.add(reception);

        //create drop down to admin menu using JMenuItem-add_employee
        JMenuItem addemployee=new JMenuItem("ADD EMPLOYEE");
        addemployee.addActionListener(this);
        admin.add(addemployee);

        JMenuItem addroom=new JMenuItem("ADD ROOM");
        addroom.addActionListener(this);
        admin.add(addroom);

        JMenuItem adddriver=new JMenuItem("ADD DRIVER");
        adddriver.addActionListener(this);
        admin.add(adddriver);


        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getActionCommand().equals("ADD EMPLOYEE"))
        {
            new AddEmployee();
        } else if (ae.getActionCommand().equals("ADD ROOM")) {
            new AddRoom();
        } else if (ae.getActionCommand().equals("ADD DRIVER")) {
            new AddDriver();
        } else if (ae.getActionCommand().equals("RECEPTION")) {
            new Reception();
        }

    }
    public static void main(String []args)
    {
        //create an object for class Dashboard
        new Dashboard();
    }
}
