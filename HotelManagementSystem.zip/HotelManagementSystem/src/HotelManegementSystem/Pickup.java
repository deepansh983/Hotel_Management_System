package HotelManegementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.*;

public class Pickup extends JFrame implements ActionListener {
    JTable table;
    JButton back,submit;
    Choice typeofcar;
    JCheckBox available;
    Pickup(){
        getContentPane().setBackground(Color.white);
        setLayout(null);

        JLabel text=new JLabel("Pickup Service");
        text.setFont(new Font("tahoma",Font.PLAIN,20));
        text.setBounds(400,30,200,30);
        add(text);

        JLabel lblcar =new JLabel("Type of Car");
        lblcar.setBounds(50,100,100,20);
        add(lblcar);

        typeofcar=new Choice();
        typeofcar.setBounds(150,100,200,25);
        add(typeofcar);

        try{
            Conn conn=new Conn();
            ResultSet rs=conn.s.executeQuery("select * from driver");
            while(rs.next())
            {
                typeofcar.add(rs.getString("model"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        JLabel j1=new JLabel("Name");
        j1.setBounds(50,160,100,20);
        add(j1);

        JLabel j2=new JLabel("Age");
        j2.setBounds(200,160,100,20);
        add(j2);

        JLabel j3=new JLabel("Gender");
        j3.setBounds(330,160,100,20);
        add(j3);

        JLabel j4=new JLabel("Company");
        j4.setBounds(470,160,100,20);
        add(j4);

        JLabel j5=new JLabel("Model");
        j5.setBounds(630,160,100,20);
        add(j5);

        JLabel j6=new JLabel("Availability");
        j6.setBounds(750,160,100,20);
        add(j6);

        JLabel j7=new JLabel("Location");
        j7.setBounds(880,160,100,20);
        add(j7);

        table=new JTable();
        table.setBounds(0,200,1000,300);
        add(table);

        try {
            Conn conn=new Conn();
            ResultSet rs=conn.s.executeQuery("select * from driver");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        submit=new JButton("Submit");
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        submit.setBounds(300,520,120,30);
        add(submit);

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(500,520,120,30);
        add(back);

        setBounds(300,200,1000,600);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==submit)
        {
            try{
                String query="select * from driver where model='"+typeofcar.getSelectedItem()+"'";

                Conn conn=new Conn();
                ResultSet rs;
               rs=conn.s.executeQuery(query);
                table.setModel(DbUtils.resultSetToTableModel(rs));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else
        {
            setVisible(false);
            new Reception();
        }
    }
    public static void main(String []args)
    {
        new Pickup();
    }
}
