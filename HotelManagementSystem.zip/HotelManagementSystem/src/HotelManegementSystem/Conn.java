package HotelManegementSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Conn {
    Connection c;
    Statement s;
    Conn(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c= DriverManager.getConnection("jdbc:mysql:///HotelManagementSystem","root","raghu@2000");
            s=c.createStatement();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
