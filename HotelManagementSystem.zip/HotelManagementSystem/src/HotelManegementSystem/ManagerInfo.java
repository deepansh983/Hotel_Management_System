package HotelManegementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import net.proteanit.sql.*;

public class ManagerInfo extends JFrame implements ActionListener {
    JTable table;
    JButton back;
    ManagerInfo(){
        getContentPane().setBackground(Color.white);
        setLayout(null);


        JLabel j1=new JLabel("Name");
        j1.setBounds(40,10,100,20);
        add(j1);

        JLabel j2=new JLabel("Age");
        j2.setBounds(180,10,100,20);
        add(j2);

        JLabel j3=new JLabel("Gender");
        j3.setBounds(290,10,100,20);
        add(j3);

        JLabel j4=new JLabel("Job");
        j4.setBounds(410,10,100,20);
        add(j4);

        JLabel j5=new JLabel("Salary");
        j5.setBounds(550,10,100,20);
        add(j5);

        JLabel j6 =new JLabel("Phone");
        j6.setBounds(660,10,100,20);
        add(j6);

        JLabel j7 =new JLabel("Email");
        j7.setBounds(790,10,100,20);
        add(j7);

        JLabel j8 =new JLabel("Aadhaar");
        j8.setBounds(900,10,100,20);
        add(j8);

        table=new JTable();
        table.setBounds(0,40,1000,400);
        add(table);

        try {
            Conn conn=new Conn();
            ResultSet rs=conn.s.executeQuery("select * from employee where Job='Manager'");
            table.setModel(DbUtils.resultSetToTableModel(rs));
        } catch (Exception e) {
            e.printStackTrace();
        }

        back=new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(420,500,120,30);
        add(back);

        setBounds(300,200,1000,600);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        setVisible(false);
        new Reception();
    }
    public static void main(String []args)
    {
        new ManagerInfo();
    }
}
