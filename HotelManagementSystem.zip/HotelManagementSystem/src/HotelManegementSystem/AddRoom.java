package HotelManegementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddRoom extends JFrame implements ActionListener {
    JButton add,cancel;
    JTextField tfroom,tfprice;
    JComboBox jbavailable,jbclean,jbbedtype;
    AddRoom(){
        getContentPane().setBackground(Color.white);
        setLayout(null);
        //create label heading
        JLabel heading=new JLabel("Add Room");
        heading.setFont(new Font("tahoma",Font.BOLD,18));
        heading.setBounds(150,20,200,20);
        add(heading);

        //create label room no
        JLabel lblroomno=new JLabel("Room Number");
        lblroomno.setFont(new Font("tahoma",Font.PLAIN,16));
        lblroomno.setBounds(60,80,120,30);
        add(lblroomno);

        //create text_field
        tfroom=new JTextField();
        tfroom.setBounds(200,80,150,30);
        add(tfroom);

        //create label available
        JLabel lblavailable=new JLabel("Available");
        lblavailable.setFont(new Font("tahoma",Font.PLAIN,16));
        lblavailable.setBounds(60,130,150,30);
        add(lblavailable);

        String availableOptions[]={"Available","Occupied"};
        jbavailable=new JComboBox(availableOptions);
        jbavailable.setBounds(200,130,150,30);
        jbavailable.setBackground(Color.white);
        add(jbavailable);

        //create label for cleaning status
        JLabel lblcleaningstatus=new JLabel("Cleaning Status");
        lblcleaningstatus.setFont(new Font("tahoma",Font.PLAIN,16));
        lblcleaningstatus.setBounds(60,180,150,30);
        add(lblcleaningstatus);

        //crate checkbox for cleaning status
        String cleanOptions[]={"Clean","Dirty"};
        jbclean=new JComboBox(cleanOptions);
        jbclean.setBounds(200,180,150,30);
        jbclean.setBackground(Color.white);
        add(jbclean);

        //crate label for price for a room
        JLabel price=new JLabel("Price");
        price.setFont(new Font("tahoma",Font.PLAIN,16));
        price.setBounds(60,230,120,30);
        add(price);

        //crate text_field for price
        tfprice=new JTextField();
        tfprice.setBounds(200,230,150,30);
        add(tfprice);

        //create label for bed type
        JLabel bedtype=new JLabel("Bed Type");
        bedtype.setFont(new Font("tahoma",Font.PLAIN,16));
        bedtype.setBounds(60,280,120,30);
        add(bedtype);

        //create check box for bed type
        String bedOptions[]={"Single Bed","Double Bed"};
        jbbedtype=new JComboBox(bedOptions);
        jbbedtype.setBounds(200,280,150,30);
        jbbedtype.setBackground(Color.white);
        add(jbbedtype);

        //create add button
        add=new JButton("Add Room");
        add.setForeground(Color.white);
        add.setBackground(Color.black);
        add.setBounds(60,350,130,30);
        add.addActionListener(this);
        add(add);

        //create cancel button
        cancel=new JButton("Cancel");
        cancel.setForeground(Color.white);
        cancel.setBackground(Color.black);
        cancel.setBounds(220,350,130,30);
        cancel.addActionListener(this);
        add(cancel);

        //add an image
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/twelve.jpg"));
        JLabel image=new JLabel(i1);
        image.setBounds(400,30,500,300);
        add(image);

        setBounds(330,200,940,470);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==add){
            String roomnumber=tfroom.getText();
            String availability= (String) jbavailable.getSelectedItem();
            String status=(String) jbclean.getSelectedItem();
            String price=tfprice.getText();
            String type=(String) jbbedtype.getSelectedItem();

            try{
                Conn conn=new Conn();
                String query="insert into room values('"+roomnumber+"','"+availability+"','"+status+"','"+price+"','"+type+"')";

                conn.s.executeUpdate(query);

                JOptionPane.showMessageDialog(null,"New room added Successfully");
                setVisible(false);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }else{
            setVisible(false);
        }
    }
    public static void main(String []args)
    {
        new AddRoom();
    }
}
