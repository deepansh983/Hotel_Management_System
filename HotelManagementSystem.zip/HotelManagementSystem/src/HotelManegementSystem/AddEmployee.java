package HotelManegementSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddEmployee extends JFrame implements ActionListener {
    JTextField tfname,tfage,tfsalary,tfphone,tfemail,tfaadhaar;
    JRadioButton rbmale,rbfemale;
    JComboBox cbjob;
    JButton submit;

    AddEmployee(){
        setLayout(null);
        //create name label
        JLabel lblname=new JLabel("NAME");
        lblname.setBounds(60,30,120,30);
        lblname.setFont(new Font("tahoma",Font.PLAIN,17));
        add(lblname);

        //create textfield for name
        tfname=new JTextField();
        tfname.setBounds(200,30,120,30);
        add(tfname);

        //create age label
        JLabel age=new JLabel("AGE");
        age.setBounds(60,80,120,30);
        age.setFont(new Font("tahoma",Font.PLAIN,17));
        add(age);

        //create age text_field
        tfage=new JTextField();
        tfage.setBounds(200,80,120,30);
        add(tfage);

        //create gender label
        JLabel gender=new JLabel("GENDER");
        gender.setBounds(60,130,120,30);
        gender.setFont(new Font("tahoma",Font.PLAIN,17));
        add(gender);

        //create radio for gender
        rbmale=new JRadioButton("MALE");
        rbmale.setBounds(200,130,70,30);
        rbmale.setFont(new Font("tahoma",Font.PLAIN,17));
        rbmale.setBackground(Color.white);
        add(rbmale);

        rbfemale=new JRadioButton("FEMALE");
        rbfemale.setBounds(280,130,90,30);
        rbfemale.setFont(new Font("tahoma",Font.PLAIN,17));
        rbfemale.setBackground(Color.white);
        add(rbfemale);

        //create button group for radio button
        ButtonGroup bg=new ButtonGroup();
        bg.add(rbmale);
        bg.add(rbfemale);

        //create job label
        JLabel job=new JLabel("JOB");
        job.setBounds(60,180,120,30);
        job.setFont(new Font("tahoma",Font.PLAIN,17));
        add(job);

        //create drop down text_field
        String str[]={"Front Desk Clerk","Manager","Accountant","Housekeeping","Chef","Waiter","Kitchen Staff","Room Service"};
        cbjob=new JComboBox<>(str);
        cbjob.setBounds(200,180,150,30);
        cbjob.setBackground(Color.white);
        add(cbjob);

        //create salary label
        JLabel salary=new JLabel("SALARY");
        salary.setBounds(60,230,120,30);
        salary.setFont(new Font("tahoma",Font.PLAIN,17));
        add(salary);

        //create salary text_field
        tfsalary=new JTextField();
        tfsalary.setBounds(200,230,120,30);
        add(tfsalary);

        //create phone label
        JLabel phone=new JLabel("PHONE");
        phone.setBounds(60,280,120,30);
        phone.setFont(new Font("tahoma",Font.PLAIN,17));
        add(phone);

        //create phone text_field
        tfphone=new JTextField();
        tfphone.setBounds(200,280,120,30);
        add(tfphone);

        //create email label
        JLabel email=new JLabel("EMAIL");
        email.setBounds(60,330,120,30);
        email.setFont(new Font("tahoma",Font.PLAIN,17));
        add(email);

        //create email text_field
        tfemail=new JTextField();
        tfemail.setBounds(200,330,120,30);
        add(tfemail);

        //create aadhaar label
        JLabel aadhaar=new JLabel("AADHAAR");
        aadhaar.setBounds(60,380,120,30);
        aadhaar.setFont(new Font("tahoma",Font.PLAIN,17));
        add(aadhaar);

        //create aadhaar text_field
        tfaadhaar=new JTextField();
        tfaadhaar.setBounds(200,380,120,30);
        add(tfaadhaar);

        //create submit text_field
        submit=new JButton("SUBMIT");
        submit.setBounds(200,430,120,30);
        submit.setFont(new Font("tahoma",Font.PLAIN,17));
        submit.setBackground(Color.BLACK);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        add(submit);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/tenth.jpg"));
        Image i2=i1.getImage().getScaledInstance(400,400,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel image=new JLabel(i3);
        image.setBounds(380,60,450,340);
        add(image);

        getContentPane().setBackground(Color.white);
        setBounds(350,200,850,540);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String name = tfname.getText();
        String age = tfage.getText();
        String salary = tfsalary.getText();
        String phone = tfphone.getText();
        String email = tfemail.getText();
        String aadhaar = tfaadhaar.getText();

        String gender = null;

        //create a validation for name ,age,salary ,job,phone,email,aadhaar
        if(name.equals("")){
            JOptionPane.showMessageDialog(null,"name should not be empty");
            return;
        }

        if(age.equals("")){
            JOptionPane.showMessageDialog(null,"age should not be empty");
            return;
        }

        if(salary.equals("")){
            JOptionPane.showMessageDialog(null,"salary should not be empty");
            return;
        }

        if(phone.equals("")){
            JOptionPane.showMessageDialog(null,"phone should not be empty");
            return;
        }

        if(email.equals("")){
            JOptionPane.showMessageDialog(null,"email should not be empty");
            return;
        }

        if(aadhaar.equals("")){
            JOptionPane.showMessageDialog(null,"aadhaar should not be empty");
            return;
        }


        if (rbmale.isSelected()) {
            gender = "MALE";
        } else if (rbfemale.isSelected()) {
            gender = "FEMALE";
        }

        String job = (String) cbjob.getSelectedItem();

        try {
            Conn conn=new Conn();

            String query="insert into employee values('"+name+"','"+age+"','"+gender+"','"+job+"','"+salary+"','"+phone+"','"+email+"','"+aadhaar+"')";


            conn.s.executeUpdate(query);
            JOptionPane.showMessageDialog(null,"Employee Added Successfully");
            setVisible(false);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public static void main (String[]args){
            new AddEmployee();
        }
    }
